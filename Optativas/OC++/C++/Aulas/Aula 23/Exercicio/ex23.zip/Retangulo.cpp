//Aluno: Renato Tanaka
#include "Retangulo.hpp"

Retangulo::Retangulo(float base, float altura)
    :base{base}, altura{altura}{
}

Retangulo::~Retangulo(){
}

float Retangulo::getArea() const{
    return this->base * this->altura;
}