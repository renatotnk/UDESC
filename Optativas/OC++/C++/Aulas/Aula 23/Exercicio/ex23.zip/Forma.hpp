//Aluno: Renato Tanaka
#ifndef FORMA_H
#define FORMA_H

class Forma{
    public:
        Forma();
        ~Forma();
        unsigned int getArea();
};
#endif