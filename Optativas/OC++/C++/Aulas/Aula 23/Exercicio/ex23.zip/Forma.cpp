//Aluno: Renato Tanaka
#include "Forma.hpp"

Forma::Forma(){
}

Forma::~Forma(){
}

unsigned int Forma::getArea(){
    return 0;
}