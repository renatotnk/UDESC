<?php

include("menu.html");

$nome = $_POST['nome'];
$lancamento = $_POST['lancamento'];
$autor = $_POST['autor'];

$link = new mysqli("localhost", "root", "", "discografia");

if($link->connect_error){
    die("A conexão falhou: " . $link->connect_error);
}

$query = "INSERT INTO discografia (nome, lancamento, autor) VALUES ('$nome', '$lancamento', '$autor')";


$status_query = mysqli_query($link, $query);

if($status_query == true){
    echo "Nova música inserida! <br> <b>Nome:</b> " . $nome. "<br><b>Data de Lançamento:</b> " . $lancamento. "<br><b>Autor(es):</b> ". $autor. ".";
}else{
    echo "Algum problema ocorreu durante a inserção da música em nosso banco de dados!";
}

mysqli_close($link);
			
?>
