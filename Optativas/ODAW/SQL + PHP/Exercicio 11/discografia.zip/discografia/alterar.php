<?php

include("menu.html");

$codigo = $_POST['coda'];
$nome = $_POST['nome'];
$lancamento = $_POST['lancamento'];
$autor = $_POST['autor'];

$link = mysqli_connect("localhost", "root", "", "discografia");

if($link->connect_error){
    die("A conexão falhou: " . $link->connect_error);
}

$query = "UPDATE discografia SET nome='$nome', lancamento='$lancamento', autor='$autor' WHERE coda='$codigo'";

$status_query = mysqli_query($link, $query);

if($status_query == true){
    echo "Dados da música alterados!<br> <b>Novo Nome:</b> " . $nome. "<br><b>Nova Data de Lançamento:</b> " . $lancamento. "<br><b>Novo(s) Autor(es):</b> ". $autor. ".";
}else{
    echo "Algum problema ocorreu durante a alteração dos dados da música em nosso banco de dados!";
}
mysqli_close($link);
			
?>
