<?php
	include("menu.html");
?>

<form action="inserir.php" method="post">
<b>Inserir novo elemento:<b><br><br>
Nome da Musica: <input type="text" name="nome" required><br>
Data de lançamento: <input type="date" name="lancamento" required><br>
Autor: <input type="text" name="autor" required><br>
<input type="submit" name="Adicionar" value="Inserir">
<button onclick="goBack()">Voltar</button>

<script>
function goBack() {
  window.history.back();
}

</script>

</form><hr>
