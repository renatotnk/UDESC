
create database discografia;
use discografia;

create table discografia (
	coda serial,
	nome varchar(50) not null,
	lancamento DATE not null,
	autor varchar(40) not null,
	primary key (coda));

insert into discografia (nome, lancamento, autor) VALUES ('Bohemian Rhapsody', '1975-10-31', 'Queen');
insert into discografia (nome, lancamento, autor) VALUES ('Thriller', '1983-12-2', 'Michael Jackson');
insert into discografia (nome, lancamento, autor) VALUES ('Help!', '1965-08-06', 'The Beatles');
