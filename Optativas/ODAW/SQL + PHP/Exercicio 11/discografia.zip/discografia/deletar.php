<?php

include("menu.html");

$codigo = $_GET['codigo'];

$link = new mysqli("localhost", "root", "", "discografia");

if($link->connect_error){
    die("A conexão falhou: " . $link->connect_error);
}

$query_print = "SELECT nome, autor FROM discografia WHERE coda='$codigo'";
$resultado = mysqli_query($link, $query_print);

if ($resultado->num_rows > 0) {
    while($row = $resultado->fetch_assoc()) {
        echo "Deletando música de nome " . $row["nome"]. " e autor " . $row["autor"]." <br>";
    }
}
$query = "DELETE FROM discografia WHERE coda='$codigo'";
//echo "DELETAR: $query<br><hr>";

$status_query = mysqli_query($link, $query);

if($status_query == true){
    echo "Música excluída com sucesso!";
}else{
    echo "Algum problema ocorreu durante a exclusão da música em nosso banco de dados!";
}
mysqli_close($link);

?>
