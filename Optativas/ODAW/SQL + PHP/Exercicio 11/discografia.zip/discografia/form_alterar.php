<?php

include("menu.html");

$codigo = $_GET['codigo'];
$nome = "";
$lancamento = "";
$autor = "";

$link = mysqli_connect("localhost", "root", "", "discografia");

$query = "SELECT * FROM discografia WHERE coda='$codigo'";
$result = mysqli_query($link, $query);
if ($row = mysqli_fetch_row($result)) {
	$nome = $row[1];
	$lancamento = $row[2];
	$autor = $row[3];
}

mysqli_close($link);

echo "
	<form action='alterar.php' method='post'>
	<b>Alterar elemento codigo $codigo:<b><br><br>
	<input type='hidden' name='coda' value='$codigo'>
	Nome: <input type='text' name='nome' value='$nome'><br>
	Data de Lançamento: <input type='date' name='lancamento' value='$lancamento'><br>
	Autor: <input type='text' name='autor' value='$autor'><br>
	<input type='submit' name='adicionar' value='Alterar'>

	</form><hr>	
";

?>
